<?php
    // Validação
    $descricao          = $_POST['descricao']          ?? null;
    $quantidade_estoque = $_POST['quantidade_estoque'] ?? 0;

    if ($descricao == null) {
        $resposta = [
            'status'    => 'erro',
            'mensagem'  => 'Por favor, informe a descrição do equipamento!'
        ];
        echo json_encode($resposta);
        exit;
    }

    // Enviar arquivo para o servidor (se fornecido)
    $nome_imagem = null;
    if (isset($_FILES['file-equipamento']) && $_FILES['file-equipamento']['size'] > 0) {
        $nome_imagem = uniqid() . '.jpg';
        $destino     = '../../upload/' . $nome_imagem;
        $origem      = $_FILES['file-equipamento']['tmp_name'];
        if (!move_uploaded_file($origem, $destino)) {
            $resposta = [
                'status'    => 'erro',
                'mensagem'  => 'Houve um problema para enviar a imagem do equipamento. Tente novamente.'
            ];
            echo json_encode($resposta);
            exit;
        }
    }

    try {
        // Banco de dados
        require_once '../class/BancoDeDados.php';
        $banco = new BancoDeDados;
        
        // Inserir novo equipamento
        $sql = 'INSERT INTO equipamentos (descricao, quantidade_estoque, foto) VALUES (?, ?, ?)';
        $parametros = [
            $descricao,
            $quantidade_estoque,
            $nome_imagem,
        ];
        $banco->executarComando($sql, $parametros);

        $resposta = [
            'status'    => 'sucesso',
            'mensagem'  => 'Equipamento cadastrado com sucesso!'
        ];
        echo json_encode($resposta);
    } catch(PDOException $erro) {
        $resposta = [
            'status'    => 'erro',
            'mensagem'  => $erro->getMessage(),
        ];
        echo json_encode($resposta);
    }