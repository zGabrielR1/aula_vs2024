<?php
    // Destruir sessão
    session_start();
    session_destroy();