// Modal
var modal = document.getElementById('modal');

function abrirModal() {
    modal.style.display = 'flex';
};

function fecharModal() {
    modal.style.display = 'none';
}