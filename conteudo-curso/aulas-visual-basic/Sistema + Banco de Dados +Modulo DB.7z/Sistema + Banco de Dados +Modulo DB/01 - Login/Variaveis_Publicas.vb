﻿Module Variaveis_Publicas
    Public id_usuario As Integer
End Module
